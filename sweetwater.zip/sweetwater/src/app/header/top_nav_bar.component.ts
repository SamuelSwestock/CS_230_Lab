import { Component } from "@angular/core";

@Component({
    selector: 'app_top_nav_bar',
    templateUrl: 'top_nav_bar.component.html'
})
export class TopNavBarComponent {

}