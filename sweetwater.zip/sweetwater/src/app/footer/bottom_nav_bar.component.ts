import { Component } from "@angular/core";

@Component({
    selector: 'app_bottom_nav_bar',
    templateUrl: 'bottom_nav_bar.component.html'
})
export class BottomNavBarComponent {

}